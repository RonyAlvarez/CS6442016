import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
public class CountNum extends HttpServlet {
 public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
  String number = request.getParameter("number");
  if(number == null){
   number = "0";
  } else {
   int v = 0;
   try{ 
    v = Integer.parseInt(number);
    } catch(Exception e) {v = 0;}
    v=v+1;
    number=""+v;
  }

  response.setContentType("text/html");
  PrintWriter out = response.getWriter();

  out.println("<html>");
  out.println("<body>");
  out.println("<h2>Click submit to increase the integer</h2>");
  out.println("Integer ---> " + number);
  out.println("<form method ='post' action='CountNum' >");
  out.println("<input type='hidden' name='number' value=\"" + number + "\">");
  out.println("<br />");
  out.println("<input type ='submit' value ='Submit'/>");
  out.println("</form>");
  out.println("</body>");
  out.println("</html>");
  }

  public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
   doPost(request, response);
  }

 }
