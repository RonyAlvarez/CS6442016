import localhost.axis.DoubleAddServer_jws.*;
public class DoubleAddClient {
  public static void main(String[] args) throws Exception {
    double value1 = 0;
    double value2 = 0;
    
    if (args.length == 2) {
       value1 = Double.parseDouble(args[0]);
       value2 = Double.parseDouble(args[1]);
     }
    else {
      System.out.println("Usage: java DoubleAddClient  [double]");
      System.exit(-1);
    }

    DoubleAddServerServiceLocator factory = new DoubleAddServerServiceLocator();
    DoubleAddServer proxy = factory.getDoubleAddServer();
    double sum = proxy.add(value1, value2);
    System.out.println("The Sum of the numbers " + value1 + " and " + value2 + " is equal to " + sum);
  }
}
