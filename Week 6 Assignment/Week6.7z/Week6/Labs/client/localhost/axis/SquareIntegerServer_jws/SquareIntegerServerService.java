/**
 * SquareIntegerServerService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.2alpha Dec 01, 2003 (04:33:24 EST) WSDL2Java emitter.
 */

package localhost.axis.SquareIntegerServer_jws;

public interface SquareIntegerServerService extends javax.xml.rpc.Service {
    public java.lang.String getSquareIntegerServerAddress();

    public localhost.axis.SquareIntegerServer_jws.SquareIntegerServer getSquareIntegerServer() throws javax.xml.rpc.ServiceException;

    public localhost.axis.SquareIntegerServer_jws.SquareIntegerServer getSquareIntegerServer(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
