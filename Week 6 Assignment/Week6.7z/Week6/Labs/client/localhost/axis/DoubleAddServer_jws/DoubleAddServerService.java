/**
 * DoubleAddServerService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.2alpha Dec 01, 2003 (04:33:24 EST) WSDL2Java emitter.
 */

package localhost.axis.DoubleAddServer_jws;

public interface DoubleAddServerService extends javax.xml.rpc.Service {
    public java.lang.String getDoubleAddServerAddress();

    public localhost.axis.DoubleAddServer_jws.DoubleAddServer getDoubleAddServer() throws javax.xml.rpc.ServiceException;

    public localhost.axis.DoubleAddServer_jws.DoubleAddServer getDoubleAddServer(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
