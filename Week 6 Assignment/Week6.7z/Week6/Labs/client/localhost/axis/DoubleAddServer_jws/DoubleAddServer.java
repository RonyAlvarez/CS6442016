/**
 * DoubleAddServer.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.2alpha Dec 01, 2003 (04:33:24 EST) WSDL2Java emitter.
 */

package localhost.axis.DoubleAddServer_jws;

public interface DoubleAddServer extends java.rmi.Remote {
    public double add(double x, double y) throws java.rmi.RemoteException;
}
