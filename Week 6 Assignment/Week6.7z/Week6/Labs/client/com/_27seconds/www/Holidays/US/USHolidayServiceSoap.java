/**
 * USHolidayServiceSoap.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.2alpha Dec 01, 2003 (04:33:24 EST) WSDL2Java emitter.
 */

package com._27seconds.www.Holidays.US;

public interface USHolidayServiceSoap extends java.rmi.Remote {

    // Get the available holidays.
    public com._27seconds.www.Holidays.US.__GetHolidaysAvailableResponse_GetHolidaysAvailableResult getHolidaysAvailable() throws java.rmi.RemoteException;

    // Get the date of a specific holiday.
    public java.util.Calendar getHolidayDate(java.lang.String getHolidayDateHolidayName, int getHolidayDateYear) throws java.rmi.RemoteException;

    // Get the holidays for a date range.
    public com._27seconds.www.Holidays.US.__GetHolidaysForDateRangeResponse_GetHolidaysForDateRangeResult getHolidaysForDateRange(java.util.Calendar getHolidaysForDateRangeStartDate, java.util.Calendar getHolidaysForDateRangeEndDate) throws java.rmi.RemoteException;

    // Get the holidays for a specific month.
    public com._27seconds.www.Holidays.US.__GetHolidaysForMonthResponse_GetHolidaysForMonthResult getHolidaysForMonth(int getHolidaysForMonthYear, int getHolidaysForMonthMonth) throws java.rmi.RemoteException;

    // Get the holidays for an entire year.
    public com._27seconds.www.Holidays.US.__GetHolidaysForYearResponse_GetHolidaysForYearResult getHolidaysForYear(int getHolidaysForYearYear) throws java.rmi.RemoteException;
}
