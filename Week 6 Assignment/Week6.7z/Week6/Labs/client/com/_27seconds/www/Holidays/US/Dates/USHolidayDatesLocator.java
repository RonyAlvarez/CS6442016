/**
 * USHolidayDatesLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.2alpha Dec 01, 2003 (04:33:24 EST) WSDL2Java emitter.
 */

package com._27seconds.www.Holidays.US.Dates;

public class USHolidayDatesLocator extends org.apache.axis.client.Service implements com._27seconds.www.Holidays.US.Dates.USHolidayDates {

    // Web service that calculates specific national holidays for the US.

    // Use to get a proxy class for USHolidayDatesSoap
    private java.lang.String USHolidayDatesSoap_address = "http://www.holidaywebservice.com/Holidays/US/Dates/USHolidayDates.asmx";

    public java.lang.String getUSHolidayDatesSoapAddress() {
        return USHolidayDatesSoap_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String USHolidayDatesSoapWSDDServiceName = "USHolidayDatesSoap";

    public java.lang.String getUSHolidayDatesSoapWSDDServiceName() {
        return USHolidayDatesSoapWSDDServiceName;
    }

    public void setUSHolidayDatesSoapWSDDServiceName(java.lang.String name) {
        USHolidayDatesSoapWSDDServiceName = name;
    }

    public com._27seconds.www.Holidays.US.Dates.USHolidayDatesSoap getUSHolidayDatesSoap() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(USHolidayDatesSoap_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getUSHolidayDatesSoap(endpoint);
    }

    public com._27seconds.www.Holidays.US.Dates.USHolidayDatesSoap getUSHolidayDatesSoap(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            com._27seconds.www.Holidays.US.Dates.USHolidayDatesSoapStub _stub = new com._27seconds.www.Holidays.US.Dates.USHolidayDatesSoapStub(portAddress, this);
            _stub.setPortName(getUSHolidayDatesSoapWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setUSHolidayDatesSoapEndpointAddress(java.lang.String address) {
        USHolidayDatesSoap_address = address;
    }


    // Use to get a proxy class for USHolidayDatesSoap12
    private java.lang.String USHolidayDatesSoap12_address = "http://www.holidaywebservice.com/Holidays/US/Dates/USHolidayDates.asmx";

    public java.lang.String getUSHolidayDatesSoap12Address() {
        return USHolidayDatesSoap12_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String USHolidayDatesSoap12WSDDServiceName = "USHolidayDatesSoap12";

    public java.lang.String getUSHolidayDatesSoap12WSDDServiceName() {
        return USHolidayDatesSoap12WSDDServiceName;
    }

    public void setUSHolidayDatesSoap12WSDDServiceName(java.lang.String name) {
        USHolidayDatesSoap12WSDDServiceName = name;
    }

    public com._27seconds.www.Holidays.US.Dates.USHolidayDatesSoap getUSHolidayDatesSoap12() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(USHolidayDatesSoap12_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getUSHolidayDatesSoap12(endpoint);
    }

    public com._27seconds.www.Holidays.US.Dates.USHolidayDatesSoap getUSHolidayDatesSoap12(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            com._27seconds.www.Holidays.US.Dates.USHolidayDatesSoap12Stub _stub = new com._27seconds.www.Holidays.US.Dates.USHolidayDatesSoap12Stub(portAddress, this);
            _stub.setPortName(getUSHolidayDatesSoap12WSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setUSHolidayDatesSoap12EndpointAddress(java.lang.String address) {
        USHolidayDatesSoap12_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     * This service has multiple ports for a given interface;
     * the proxy implementation returned may be indeterminate.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (com._27seconds.www.Holidays.US.Dates.USHolidayDatesSoap.class.isAssignableFrom(serviceEndpointInterface)) {
                com._27seconds.www.Holidays.US.Dates.USHolidayDatesSoapStub _stub = new com._27seconds.www.Holidays.US.Dates.USHolidayDatesSoapStub(new java.net.URL(USHolidayDatesSoap_address), this);
                _stub.setPortName(getUSHolidayDatesSoapWSDDServiceName());
                return _stub;
            }
            if (com._27seconds.www.Holidays.US.Dates.USHolidayDatesSoap.class.isAssignableFrom(serviceEndpointInterface)) {
                com._27seconds.www.Holidays.US.Dates.USHolidayDatesSoap12Stub _stub = new com._27seconds.www.Holidays.US.Dates.USHolidayDatesSoap12Stub(new java.net.URL(USHolidayDatesSoap12_address), this);
                _stub.setPortName(getUSHolidayDatesSoap12WSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        String inputPortName = portName.getLocalPart();
        if ("USHolidayDatesSoap".equals(inputPortName)) {
            return getUSHolidayDatesSoap();
        }
        else if ("USHolidayDatesSoap12".equals(inputPortName)) {
            return getUSHolidayDatesSoap12();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://www.27seconds.com/Holidays/US/Dates/", "USHolidayDates");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("USHolidayDatesSoap"));
            ports.add(new javax.xml.namespace.QName("USHolidayDatesSoap12"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        if ("USHolidayDatesSoap".equals(portName)) {
            setUSHolidayDatesSoapEndpointAddress(address);
        }
        if ("USHolidayDatesSoap12".equals(portName)) {
            setUSHolidayDatesSoap12EndpointAddress(address);
        }
        else { // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
