/**
 * USHolidayDates.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.2alpha Dec 01, 2003 (04:33:24 EST) WSDL2Java emitter.
 */

package com._27seconds.www.Holidays.US.Dates;

public interface USHolidayDates extends javax.xml.rpc.Service {

    // Web service that calculates specific national holidays for the US.
    public java.lang.String getUSHolidayDatesSoapAddress();

    public com._27seconds.www.Holidays.US.Dates.USHolidayDatesSoap getUSHolidayDatesSoap() throws javax.xml.rpc.ServiceException;

    public com._27seconds.www.Holidays.US.Dates.USHolidayDatesSoap getUSHolidayDatesSoap(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
    public java.lang.String getUSHolidayDatesSoap12Address();

    public com._27seconds.www.Holidays.US.Dates.USHolidayDatesSoap getUSHolidayDatesSoap12() throws javax.xml.rpc.ServiceException;

    public com._27seconds.www.Holidays.US.Dates.USHolidayDatesSoap getUSHolidayDatesSoap12(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
