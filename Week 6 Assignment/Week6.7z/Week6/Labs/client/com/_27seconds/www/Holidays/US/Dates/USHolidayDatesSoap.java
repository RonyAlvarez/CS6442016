/**
 * USHolidayDatesSoap.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.2alpha Dec 01, 2003 (04:33:24 EST) WSDL2Java emitter.
 */

package com._27seconds.www.Holidays.US.Dates;

public interface USHolidayDatesSoap extends java.rmi.Remote {

    // Get the date of New Year.
    public java.util.Calendar getNewYear(int getNewYearYear) throws java.rmi.RemoteException;

    // Get the date of Martin Luther King Day.
    public java.util.Calendar getMartinLutherKingDay(int getMartinLutherKingDayYear) throws java.rmi.RemoteException;

    // Get the date of President's Day.
    public java.util.Calendar getPresidentsDay(int getPresidentsDayYear) throws java.rmi.RemoteException;

    // Get the date of Abraham Lincoln's Birthday.
    public java.util.Calendar getAbrahamLincolnsBirthday(int getAbrahamLincolnsBirthdayYear) throws java.rmi.RemoteException;

    // Get the date of Valentines Day.
    public java.util.Calendar getValentinesDay(int getValentinesDayYear) throws java.rmi.RemoteException;

    // Get the date of George Washington's Birthday.
    public java.util.Calendar getGeorgeWashingtonsBirthday(int getGeorgeWashingtonsBirthdayYear) throws java.rmi.RemoteException;

    // Get the date of Good Friday.
    public java.util.Calendar getGoodFriday(int getGoodFridayYear) throws java.rmi.RemoteException;

    // Get the date of Easter.
    public java.util.Calendar getEaster(int getEasterYear) throws java.rmi.RemoteException;

    // Get the date of Saint Patrick's Day.
    public java.util.Calendar getSaintPatricksDay(int getSaintPatricksDayYear) throws java.rmi.RemoteException;

    // Get the date of April Fool's Day.
    public java.util.Calendar getAprilFoolsDay(int getAprilFoolsDayYear) throws java.rmi.RemoteException;

    // Get the date of Mother's Day.
    public java.util.Calendar getMothersDay(int getMothersDayYear) throws java.rmi.RemoteException;

    // Get the date of Memorial Day.
    public java.util.Calendar getMemorialDay(int getMemorialDayYear) throws java.rmi.RemoteException;

    // Get the date of Cinco de Mayo.
    public java.util.Calendar getCincoDeMayo(int getCincoDeMayoYear) throws java.rmi.RemoteException;

    // Get the date of Father's Day.
    public java.util.Calendar getFathersDay(int getFathersDayYear) throws java.rmi.RemoteException;

    // Get the date of Flag Day.
    public java.util.Calendar getFlagDay(int getFlagDayYear) throws java.rmi.RemoteException;

    // Get the date of Independence Day.
    public java.util.Calendar getIndependenceDay(int getIndependenceDayYear) throws java.rmi.RemoteException;

    // Get the date of Labor Day.
    public java.util.Calendar getLaborDay(int getLaborDayYear) throws java.rmi.RemoteException;

    // Get the date of Columbus Day.
    public java.util.Calendar getColumbusDay(int getColumbusDayYear) throws java.rmi.RemoteException;

    // Get the date of Halloween Day.
    public java.util.Calendar getHalloweenDay(int getHalloweenDayYear) throws java.rmi.RemoteException;

    // Get the date of Thanksgiving Day.
    public java.util.Calendar getThanksgivingDay(int getThanksgivingDayYear) throws java.rmi.RemoteException;

    // Get the date of Black Friday.
    public java.util.Calendar getBlackFriday(int getBlackFridayYear) throws java.rmi.RemoteException;

    // Get the date of Veteran's Day.
    public java.util.Calendar getVeteransDay(int getVeteransDayYear) throws java.rmi.RemoteException;

    // Get the date of Christmas.
    public java.util.Calendar getChristmasDay(int getChristmasDayYear) throws java.rmi.RemoteException;

    // Get the date of New Year's Eve.
    public java.util.Calendar getNewYearsEve(int getNewYearsEveYear) throws java.rmi.RemoteException;
}
