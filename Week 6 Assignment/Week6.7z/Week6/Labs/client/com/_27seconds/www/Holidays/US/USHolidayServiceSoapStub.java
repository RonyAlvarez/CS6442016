/**
 * USHolidayServiceSoapStub.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.2alpha Dec 01, 2003 (04:33:24 EST) WSDL2Java emitter.
 */

package com._27seconds.www.Holidays.US;

public class USHolidayServiceSoapStub extends org.apache.axis.client.Stub implements com._27seconds.www.Holidays.US.USHolidayServiceSoap {
    private java.util.Vector cachedSerClasses = new java.util.Vector();
    private java.util.Vector cachedSerQNames = new java.util.Vector();
    private java.util.Vector cachedSerFactories = new java.util.Vector();
    private java.util.Vector cachedDeserFactories = new java.util.Vector();

    static org.apache.axis.description.OperationDesc [] _operations;

    static {
        _operations = new org.apache.axis.description.OperationDesc[5];
        _initOperationDesc1();
    }

    private static void _initOperationDesc1(){
        org.apache.axis.description.OperationDesc oper;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetHolidaysAvailable");
        oper.setReturnType(new javax.xml.namespace.QName("http://www.27seconds.com/Holidays/US/", ">>GetHolidaysAvailableResponse>GetHolidaysAvailableResult"));
        oper.setReturnClass(com._27seconds.www.Holidays.US.__GetHolidaysAvailableResponse_GetHolidaysAvailableResult.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.27seconds.com/Holidays/US/", "GetHolidaysAvailableResult"));
        oper.setStyle(org.apache.axis.enum.Style.WRAPPED);
        oper.setUse(org.apache.axis.enum.Use.LITERAL);
        _operations[0] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetHolidayDate");
        oper.addParameter(new javax.xml.namespace.QName("http://www.27seconds.com/Holidays/US/", "holidayName"), new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, org.apache.axis.description.ParameterDesc.IN, false, false);
        oper.addParameter(new javax.xml.namespace.QName("http://www.27seconds.com/Holidays/US/", "year"), new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, org.apache.axis.description.ParameterDesc.IN, false, false);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        oper.setReturnClass(java.util.Calendar.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.27seconds.com/Holidays/US/", "GetHolidayDateResult"));
        oper.setStyle(org.apache.axis.enum.Style.WRAPPED);
        oper.setUse(org.apache.axis.enum.Use.LITERAL);
        _operations[1] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetHolidaysForDateRange");
        oper.addParameter(new javax.xml.namespace.QName("http://www.27seconds.com/Holidays/US/", "startDate"), new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"), java.util.Calendar.class, org.apache.axis.description.ParameterDesc.IN, false, false);
        oper.addParameter(new javax.xml.namespace.QName("http://www.27seconds.com/Holidays/US/", "endDate"), new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"), java.util.Calendar.class, org.apache.axis.description.ParameterDesc.IN, false, false);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.27seconds.com/Holidays/US/", ">>GetHolidaysForDateRangeResponse>GetHolidaysForDateRangeResult"));
        oper.setReturnClass(com._27seconds.www.Holidays.US.__GetHolidaysForDateRangeResponse_GetHolidaysForDateRangeResult.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.27seconds.com/Holidays/US/", "GetHolidaysForDateRangeResult"));
        oper.setStyle(org.apache.axis.enum.Style.WRAPPED);
        oper.setUse(org.apache.axis.enum.Use.LITERAL);
        _operations[2] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetHolidaysForMonth");
        oper.addParameter(new javax.xml.namespace.QName("http://www.27seconds.com/Holidays/US/", "year"), new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, org.apache.axis.description.ParameterDesc.IN, false, false);
        oper.addParameter(new javax.xml.namespace.QName("http://www.27seconds.com/Holidays/US/", "month"), new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, org.apache.axis.description.ParameterDesc.IN, false, false);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.27seconds.com/Holidays/US/", ">>GetHolidaysForMonthResponse>GetHolidaysForMonthResult"));
        oper.setReturnClass(com._27seconds.www.Holidays.US.__GetHolidaysForMonthResponse_GetHolidaysForMonthResult.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.27seconds.com/Holidays/US/", "GetHolidaysForMonthResult"));
        oper.setStyle(org.apache.axis.enum.Style.WRAPPED);
        oper.setUse(org.apache.axis.enum.Use.LITERAL);
        _operations[3] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetHolidaysForYear");
        oper.addParameter(new javax.xml.namespace.QName("http://www.27seconds.com/Holidays/US/", "year"), new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, org.apache.axis.description.ParameterDesc.IN, false, false);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.27seconds.com/Holidays/US/", ">>GetHolidaysForYearResponse>GetHolidaysForYearResult"));
        oper.setReturnClass(com._27seconds.www.Holidays.US.__GetHolidaysForYearResponse_GetHolidaysForYearResult.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.27seconds.com/Holidays/US/", "GetHolidaysForYearResult"));
        oper.setStyle(org.apache.axis.enum.Style.WRAPPED);
        oper.setUse(org.apache.axis.enum.Use.LITERAL);
        _operations[4] = oper;

    }

    public USHolidayServiceSoapStub() throws org.apache.axis.AxisFault {
         this(null);
    }

    public USHolidayServiceSoapStub(java.net.URL endpointURL, javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
         this(service);
         super.cachedEndpoint = endpointURL;
    }

    public USHolidayServiceSoapStub(javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
        if (service == null) {
            super.service = new org.apache.axis.client.Service();
        } else {
            super.service = service;
        }
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("http://www.27seconds.com/Holidays/US/", ">>GetHolidaysForDateRangeResponse>GetHolidaysForDateRangeResult");
            cachedSerQNames.add(qName);
            cls = com._27seconds.www.Holidays.US.__GetHolidaysForDateRangeResponse_GetHolidaysForDateRangeResult.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.27seconds.com/Holidays/US/", ">DataSet");
            cachedSerQNames.add(qName);
            cls = com._27seconds.www.Holidays.US._DataSet.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.27seconds.com/Holidays/US/", ">GetHolidayDate");
            cachedSerQNames.add(qName);
            cls = com._27seconds.www.Holidays.US._GetHolidayDate.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.27seconds.com/Holidays/US/", ">GetHolidaysForYear");
            cachedSerQNames.add(qName);
            cls = com._27seconds.www.Holidays.US._GetHolidaysForYear.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.27seconds.com/Holidays/US/", ">GetHolidaysForDateRange");
            cachedSerQNames.add(qName);
            cls = com._27seconds.www.Holidays.US._GetHolidaysForDateRange.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.27seconds.com/Holidays/US/", ">GetHolidaysForYearResponse");
            cachedSerQNames.add(qName);
            cls = com._27seconds.www.Holidays.US._GetHolidaysForYearResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.27seconds.com/Holidays/US/", ">>GetHolidaysAvailableResponse>GetHolidaysAvailableResult");
            cachedSerQNames.add(qName);
            cls = com._27seconds.www.Holidays.US.__GetHolidaysAvailableResponse_GetHolidaysAvailableResult.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.27seconds.com/Holidays/US/", ">GetHolidaysForMonth");
            cachedSerQNames.add(qName);
            cls = com._27seconds.www.Holidays.US._GetHolidaysForMonth.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.27seconds.com/Holidays/US/", ">GetHolidayDateResponse");
            cachedSerQNames.add(qName);
            cls = com._27seconds.www.Holidays.US._GetHolidayDateResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.27seconds.com/Holidays/US/", ">>GetHolidaysForYearResponse>GetHolidaysForYearResult");
            cachedSerQNames.add(qName);
            cls = com._27seconds.www.Holidays.US.__GetHolidaysForYearResponse_GetHolidaysForYearResult.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.27seconds.com/Holidays/US/", ">GetHolidaysForDateRangeResponse");
            cachedSerQNames.add(qName);
            cls = com._27seconds.www.Holidays.US._GetHolidaysForDateRangeResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.27seconds.com/Holidays/US/", ">GetHolidaysForMonthResponse");
            cachedSerQNames.add(qName);
            cls = com._27seconds.www.Holidays.US._GetHolidaysForMonthResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.27seconds.com/Holidays/US/", ">>GetHolidaysForMonthResponse>GetHolidaysForMonthResult");
            cachedSerQNames.add(qName);
            cls = com._27seconds.www.Holidays.US.__GetHolidaysForMonthResponse_GetHolidaysForMonthResult.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

    }

    private org.apache.axis.client.Call createCall() throws java.rmi.RemoteException {
        try {
            org.apache.axis.client.Call _call =
                    (org.apache.axis.client.Call) super.service.createCall();
            if (super.maintainSessionSet) {
                _call.setMaintainSession(super.maintainSession);
            }
            if (super.cachedUsername != null) {
                _call.setUsername(super.cachedUsername);
            }
            if (super.cachedPassword != null) {
                _call.setPassword(super.cachedPassword);
            }
            if (super.cachedEndpoint != null) {
                _call.setTargetEndpointAddress(super.cachedEndpoint);
            }
            if (super.cachedTimeout != null) {
                _call.setTimeout(super.cachedTimeout);
            }
            if (super.cachedPortName != null) {
                _call.setPortName(super.cachedPortName);
            }
            java.util.Enumeration keys = super.cachedProperties.keys();
            while (keys.hasMoreElements()) {
                java.lang.String key = (java.lang.String) keys.nextElement();
                _call.setProperty(key, super.cachedProperties.get(key));
            }
            // All the type mapping information is registered
            // when the first call is made.
            // The type mapping information is actually registered in
            // the TypeMappingRegistry of the service, which
            // is the reason why registration is only needed for the first call.
            synchronized (this) {
                if (firstCall()) {
                    // must set encoding style before registering serializers
                    _call.setEncodingStyle(null);
                    for (int i = 0; i < cachedSerFactories.size(); ++i) {
                        java.lang.Class cls = (java.lang.Class) cachedSerClasses.get(i);
                        javax.xml.namespace.QName qName =
                                (javax.xml.namespace.QName) cachedSerQNames.get(i);
                        java.lang.Class sf = (java.lang.Class)
                                 cachedSerFactories.get(i);
                        java.lang.Class df = (java.lang.Class)
                                 cachedDeserFactories.get(i);
                        _call.registerTypeMapping(cls, qName, sf, df, false);
                    }
                }
            }
            return _call;
        }
        catch (java.lang.Throwable t) {
            throw new org.apache.axis.AxisFault("Failure trying to get the Call object", t);
        }
    }

    public com._27seconds.www.Holidays.US.__GetHolidaysAvailableResponse_GetHolidaysAvailableResult getHolidaysAvailable() throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[0]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.27seconds.com/Holidays/US/GetHolidaysAvailable");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.27seconds.com/Holidays/US/", "GetHolidaysAvailable"));

        setRequestHeaders(_call);
        setAttachments(_call);
        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com._27seconds.www.Holidays.US.__GetHolidaysAvailableResponse_GetHolidaysAvailableResult) _resp;
            } catch (java.lang.Exception _exception) {
                return (com._27seconds.www.Holidays.US.__GetHolidaysAvailableResponse_GetHolidaysAvailableResult) org.apache.axis.utils.JavaUtils.convert(_resp, com._27seconds.www.Holidays.US.__GetHolidaysAvailableResponse_GetHolidaysAvailableResult.class);
            }
        }
    }

    public java.util.Calendar getHolidayDate(java.lang.String getHolidayDateHolidayName, int getHolidayDateYear) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[1]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.27seconds.com/Holidays/US/GetHolidayDate");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.27seconds.com/Holidays/US/", "GetHolidayDate"));

        setRequestHeaders(_call);
        setAttachments(_call);
        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {getHolidayDateHolidayName, new java.lang.Integer(getHolidayDateYear)});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (java.util.Calendar) _resp;
            } catch (java.lang.Exception _exception) {
                return (java.util.Calendar) org.apache.axis.utils.JavaUtils.convert(_resp, java.util.Calendar.class);
            }
        }
    }

    public com._27seconds.www.Holidays.US.__GetHolidaysForDateRangeResponse_GetHolidaysForDateRangeResult getHolidaysForDateRange(java.util.Calendar getHolidaysForDateRangeStartDate, java.util.Calendar getHolidaysForDateRangeEndDate) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[2]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.27seconds.com/Holidays/US/GetHolidaysForDateRange");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.27seconds.com/Holidays/US/", "GetHolidaysForDateRange"));

        setRequestHeaders(_call);
        setAttachments(_call);
        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {getHolidaysForDateRangeStartDate, getHolidaysForDateRangeEndDate});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com._27seconds.www.Holidays.US.__GetHolidaysForDateRangeResponse_GetHolidaysForDateRangeResult) _resp;
            } catch (java.lang.Exception _exception) {
                return (com._27seconds.www.Holidays.US.__GetHolidaysForDateRangeResponse_GetHolidaysForDateRangeResult) org.apache.axis.utils.JavaUtils.convert(_resp, com._27seconds.www.Holidays.US.__GetHolidaysForDateRangeResponse_GetHolidaysForDateRangeResult.class);
            }
        }
    }

    public com._27seconds.www.Holidays.US.__GetHolidaysForMonthResponse_GetHolidaysForMonthResult getHolidaysForMonth(int getHolidaysForMonthYear, int getHolidaysForMonthMonth) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[3]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.27seconds.com/Holidays/US/GetHolidaysForMonth");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.27seconds.com/Holidays/US/", "GetHolidaysForMonth"));

        setRequestHeaders(_call);
        setAttachments(_call);
        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {new java.lang.Integer(getHolidaysForMonthYear), new java.lang.Integer(getHolidaysForMonthMonth)});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com._27seconds.www.Holidays.US.__GetHolidaysForMonthResponse_GetHolidaysForMonthResult) _resp;
            } catch (java.lang.Exception _exception) {
                return (com._27seconds.www.Holidays.US.__GetHolidaysForMonthResponse_GetHolidaysForMonthResult) org.apache.axis.utils.JavaUtils.convert(_resp, com._27seconds.www.Holidays.US.__GetHolidaysForMonthResponse_GetHolidaysForMonthResult.class);
            }
        }
    }

    public com._27seconds.www.Holidays.US.__GetHolidaysForYearResponse_GetHolidaysForYearResult getHolidaysForYear(int getHolidaysForYearYear) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[4]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.27seconds.com/Holidays/US/GetHolidaysForYear");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.27seconds.com/Holidays/US/", "GetHolidaysForYear"));

        setRequestHeaders(_call);
        setAttachments(_call);
        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {new java.lang.Integer(getHolidaysForYearYear)});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com._27seconds.www.Holidays.US.__GetHolidaysForYearResponse_GetHolidaysForYearResult) _resp;
            } catch (java.lang.Exception _exception) {
                return (com._27seconds.www.Holidays.US.__GetHolidaysForYearResponse_GetHolidaysForYearResult) org.apache.axis.utils.JavaUtils.convert(_resp, com._27seconds.www.Holidays.US.__GetHolidaysForYearResponse_GetHolidaysForYearResult.class);
            }
        }
    }

}
