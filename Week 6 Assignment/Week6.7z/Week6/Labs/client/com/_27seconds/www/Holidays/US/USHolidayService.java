/**
 * USHolidayService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.2alpha Dec 01, 2003 (04:33:24 EST) WSDL2Java emitter.
 */

package com._27seconds.www.Holidays.US;

public interface USHolidayService extends javax.xml.rpc.Service {

    // Web service that calculates national holidays for the US.
    public java.lang.String getUSHolidayServiceSoap12Address();

    public com._27seconds.www.Holidays.US.USHolidayServiceSoap getUSHolidayServiceSoap12() throws javax.xml.rpc.ServiceException;

    public com._27seconds.www.Holidays.US.USHolidayServiceSoap getUSHolidayServiceSoap12(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
    public java.lang.String getUSHolidayServiceSoapAddress();

    public com._27seconds.www.Holidays.US.USHolidayServiceSoap getUSHolidayServiceSoap() throws javax.xml.rpc.ServiceException;

    public com._27seconds.www.Holidays.US.USHolidayServiceSoap getUSHolidayServiceSoap(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
