import com._27seconds.www.Holidays.US.Dates.*;
import java.util.*;
public class USHolidaysClient {
 public static void main(String[] args) throws Exception {
 int year = 0; // year
 // The program expects to receive an integer (year) on command-line
 // Program quits if there is no such integer
 if (args.length == 1) // there is one command-line argument
 year = Integer.parseInt(args[0]); // parse the string to an int
 else {
 System.out.println("Usage: java USHolidaysClient [integer]");
 System.exit(-1); // terminate the program
 }
 // Get the proxy factory
 USHolidayDatesLocator factory = new USHolidayDatesLocator();
 // Generate the web service proxy object
 USHolidayDatesSoap proxy = factory.getUSHolidayDatesSoap();
 // Access the Web service
 Calendar cal;
 cal = proxy.getEaster(year);
 cal.add(Calendar.DAY_OF_MONTH, 1);
 System.out.println("Easter: \t" + (cal.get(Calendar.MONTH)+1) +
 "/" + cal.get(Calendar.DAY_OF_MONTH) + "/" + cal.get(Calendar.YEAR));
 cal = proxy.getMothersDay(year);
 cal.add(Calendar.DAY_OF_MONTH, 1);
System.out.println("Mother's Day: \t" + (cal.get(Calendar.MONTH)+1) +
 "/" + cal.get(Calendar.DAY_OF_MONTH) + "/" + cal.get(Calendar.YEAR));
 cal = proxy.getFathersDay(year);
 cal.add(Calendar.DAY_OF_MONTH, 1);
 System.out.println("Father's Day: \t" + (cal.get(Calendar.MONTH)+1) +
 "/" + cal.get(Calendar.DAY_OF_MONTH) + "/" + cal.get(Calendar.YEAR));
 cal = proxy.getThanksgivingDay(year);
 cal.add(Calendar.DAY_OF_MONTH, 1);
 System.out.println("Thanksgiving: \t" + (cal.get(Calendar.MONTH)+1) +
 "/" + cal.get(Calendar.DATE) + "/" + cal.get(Calendar.YEAR));
 cal = Calendar.getInstance();
 System.out.println("Today: \t\t" + (cal.get(Calendar.MONTH)+1) +
 "/" + cal.get(Calendar.DAY_OF_MONTH) + "/" + cal.get(Calendar.YEAR));
 }
} 
